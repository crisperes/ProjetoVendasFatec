# ProjetoVendasFatec
P2 Laboratorio Banco de Dados - Cristoffer - Gabriel - Guilherme - Luciano

Bom Dia, Boa Tarde, Boa Noite, Criamos este Projeto/Sistema na Aula de Laboratorio de Banco de Dados na Fatec Santana de Parnaíba
Com as Instruções do Professor CAIO VINICIUS MALHEIROS DUARTE.
O sistema em si é voltado para vendas em um nível simples e basíco de recursos e detalhes,
onde realiza o cadastro de produtos, clientes e exportação do relatório de vendas para uma planilha do Excel.
